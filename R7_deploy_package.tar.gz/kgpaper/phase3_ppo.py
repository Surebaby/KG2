"""Phase 3b — PPO + GAE + Critic + Reference Model (default on Pro 6000 96 GB).

Fixes bugs #8 and #9: the legacy script used a single scalar reward per
trajectory and never invoked the critic head. Here we run a full TRL
``PPOTrainer`` with:

- a frozen reference model (the Phase 3a SFT checkpoint),
- a policy model (also initialised from SFT, then PEFT-LoRA-tuned),
- a value head attached to the policy (TRL provides it in
  ``AutoModelForCausalLMWithValueHead``),
- a per-step composite reward function via
  :class:`kgproweight.training.reward_function.KGProWeightRewardFunction`,
- per-token reward shaping that places the step reward on the last token
  of the corresponding ``[Step N]`` span.

We also support an ``alpha_override`` for the alpha-ablations
(``α=0`` / ``α=0.5`` / ``α=1``) by passing the value straight to the
reward function.
"""

from __future__ import annotations

# --- Fix AutoDL OMP_NUM_THREADS libgomp freeze (before any C-extension import) ---
import os as _os
if "OMP_NUM_THREADS" in _os.environ:
    try:
        int(_os.environ["OMP_NUM_THREADS"])
    except (ValueError, TypeError):
        _os.environ["OMP_NUM_THREADS"] = "8"

import json
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import torch

from kgproweight.data.parsers import parse_steps
from kgproweight.data.prompts import build_rl_messages
from kgproweight.data.silver_dataset import SilverDatasetReader
from kgproweight.reward.alpha_gate import AlphaGate
from kgproweight.reward.prm_annotator import PRMAnnotator
from kgproweight.reward.text_reward_model import build_text_reward_model
from kgproweight.training.reward_function import (
    KGProWeightRewardFunction,
    RewardSpec,
    step_spans_over_ids,
)
from kgproweight.training.step_reward_ppo_trainer import StepRewardPPOTrainer
from kgproweight.utils.logging import dump_manifest, get_logger
from kgproweight.utils.paths import model_path
from kgproweight.utils.seed import set_seed

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class Phase3PPOConfig:
    silver_path: str
    output_dir: str
    base_model: str = "llama3-8B-instruct"
    sft_checkpoint: Optional[str] = None
    alpha_gate_path: Optional[str] = None
    text_reward_backend: str = "auto"  # rearag | llama_head | auto | dummy
    text_reward_fallback_path: Optional[str] = None
    dtype: str = "bf16"
    seed: int = 42

    # PPO
    learning_rate: float = 1.0e-5
    batch_size: int = 64       # overridden in YAML to 8
    mini_batch_size: int = 2   # R4: 2 (was 8 default, overridden per-run)
    ppo_epochs: int = 4
    cliprange: float = 0.2
    cliprange_value: float = 0.2  # value-function clip range (TRL default 0.2)
    # KL anchor: 0.1 is the midpoint. 0.2 locked the policy to SFT
    # (only rephrasing, not changing answers); 0.05 was too loose (policy
    # dropped [Step N] structure to chase reward). Combined with
    # R7: sft_anchor replaces step_format_bonus; format is now a constraint.
    kl_coef: float = 0.1
    gamma: float = 0.95
    lam: float = 0.95
    max_grad_norm: float = 1.0
    total_steps: int = 3000
    vf_coef: float = 0.5
    # Adaptive-controller target KL (TRL's `target`), NOT the early-stop knob.
    target_kl: float = 8.0
    # Horizon for the adaptive KL controller.
    kl_horizon: float = 2000.0
    early_stopping: bool = False
    # EM bonus weight: when the predicted answer matches the gold, the final
    # step gets +outcome_weight. 5.0 makes "answer correct" dominant (~5x the
    # per-step R_text noise), so PPO learns to improve answers rather than just
    # rephrase.
    outcome_weight: float = 8.0  # R5: stronger EM signal for hard examples
    # R5: scale R_text range. 0.3 maps ReaRAG's (−1,1) output to (−0.3,0.3),
    # keeping the text signal as a weak directional hint while letting EM and
    # R_KG dominate the reward. This is the key structural fix vs R3/R4.
    text_reward_scale: float = 0.3
    # R7: format bonus REMOVED. Format is a constraint (ValidTrajectory gate),
    # not a reward target. Combined with lightweight SFT anchor (see below).
    min_valid_steps: int = 3
    sft_anchor_weight: float = 0.02
    sft_anchor_interval: int = 50
    # Pure EM reward mode (ablation): skip R_KG, R_text, and α-gate entirely.
    # Reward = EM × outcome_weight (now conditional on ValidTrajectory).
    pure_em_reward: bool = False
    # Logging
    log_with: Optional[str] = None  # "wandb" or None
    # Save a recoverable adapter checkpoint every N trajectories seen (0 = only
    # at the end). Lets a collapsed run roll back to the last healthy step.
    save_every_steps: int = 256

    # Generation
    max_new_tokens: int = 384
    # PPO ROLLOUT SAMPLING MUST MATCH TRL's logprob recomputation distribution.
    # TRL's batched_forward_pass scores responses from RAW logits — i.e.
    # temperature=1.0, no top_p, no top_k. If we sample at temperature=0.7 /
    # top_p=0.9 (a sharper, truncated distribution) the recomputed logp_old is
    # not the distribution the tokens were actually drawn from, so the PPO ratio
    # baseline is wrong and the KL estimate drifts NEGATIVE (the 2026-06-23
    # symptom: KL swung 60→0.34→-20). Keep these at the no-op values and disable
    # top_k in the generate() call so rollout == scoring distribution.
    temperature: float = 1.0
    top_p: float = 1.0
    max_input_length: int = 4096
    # B5: cap parsed [Step N] blocks per rollout (matches reward_fn.max_steps).
    max_steps: int = 7
    # B3: the prompt template orders Question → Passages → KG, and the tokenizer
    # right-truncates. With the package defaults (50 passages) the KG block — the
    # whole point of KG-grounding — gets truncated away before the model sees it
    # during rollouts. Cap passages so the KG always fits.
    # Unified with SFT/eval (DEFAULT_TOPK=15) so PPO rolls out in the SAME
    # passage context the policy is later evaluated in (no train/inference
    # mismatch). 15 passages + KG fit max_input_length=6144; on a 96GB card the
    # policy (8B) + frozen SFT ref + ReaRAG-9B reward co-reside (~50GB) with room
    # for activations at batch_size=8 / mini_batch_size=1 + gradient checkpointing.
    # If OOM: drop batch_size 8→4, then ppo_max_kg_triples 30→20, then passages.
    ppo_max_passages: int = 15
    ppo_max_kg_triples: int = 30

    # LoRA on policy
    use_lora: bool = True
    lora_r: int = 32
    lora_alpha: int = 64
    lora_dropout: float = 0.05

    # Ablation hooks
    alpha_override: Optional[float] = None
    binary_labels_only: bool = False
    # P1-1: use real per-step token logprobs for the α-gate's entropy feature.
    use_real_logprobs: bool = True

    extra: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_models(cfg: Phase3PPOConfig):
    """Build policy+value, reference, and tokenizer.

    BUGFIX (2026-06-22): the previous version passed ``base_id`` = SFT-adapter
    dir together with a fresh ``peft_config``. TRL's ``from_pretrained`` ignores
    ``peft_config`` when an ``adapter_config.json`` is present and loads the
    trained adapter with ``is_trainable=False`` (the default) — so the SFT LoRA
    was loaded FROZEN, PPO produced zero gradient on it, and the saved checkpoint
    was byte-identical to SFT. We now load the SFT adapter as TRAINABLE and anchor
    the KL reference to a frozen SFT copy (not the bare base, which is what
    adapter-disabling would give and which would penalise SFT-acquired behaviour).
    """
    import os
    import torch as _torch
    from transformers import AutoTokenizer
    from trl import AutoModelForCausalLMWithValueHead, create_reference_model

    dtype_map = {"bf16": _torch.bfloat16, "fp16": _torch.float16, "fp32": _torch.float32}
    torch_dtype = dtype_map.get(cfg.dtype, _torch.bfloat16)
    base_id = cfg.sft_checkpoint or model_path(cfg.base_model)

    tokenizer = AutoTokenizer.from_pretrained(base_id)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    has_adapter = os.path.exists(os.path.join(str(base_id), "adapter_config.json"))
    policy_kwargs: Dict[str, Any] = {"torch_dtype": torch_dtype}
    is_peft = False

    if has_adapter:
        # base_id is a trained PEFT adapter dir (the SFT student). TRL will load
        # base + this adapter; force is_trainable=True so PPO can update it and
        # save_pretrained writes the UPDATED weights (SFT+PPO in one adapter).
        policy_kwargs["is_trainable"] = True
        is_peft = True
    elif cfg.use_lora:
        # Fresh start from the bare base model: attach a new trainable LoRA.
        try:
            from peft import LoraConfig

            policy_kwargs["peft_config"] = LoraConfig(
                r=cfg.lora_r,
                lora_alpha=cfg.lora_alpha,
                lora_dropout=cfg.lora_dropout,
                target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
                bias="none",
                task_type="CAUSAL_LM",
            )
            is_peft = True
        except ImportError:
            logger.warning("peft not installed; PPO will fine-tune all parameters.")

    policy = AutoModelForCausalLMWithValueHead.from_pretrained(base_id, **policy_kwargs)

    # Sanity: confirm at least one LoRA parameter is actually trainable, so a
    # frozen-adapter regression can never silently return (the original bug).
    if is_peft:
        n_trainable = sum(p.numel() for p in policy.parameters() if p.requires_grad)
        logger.info("Policy trainable params: %d", n_trainable)
        if n_trainable == 0:
            raise RuntimeError(
                "Policy has 0 trainable parameters — the LoRA adapter loaded frozen. "
                "PPO would be a no-op (this was the 2026-06-22 bug). Aborting."
            )

    # Activation memory: enable gradient checkpointing on the POLICY so the 8B
    # policy + frozen SFT reference + ReaRAG-9B reward co-reside on one 96GB card
    # (the 2026-06-22 run sat at ~93/96GB without it — one long rollout from OOM).
    # The value-head wrapper proxies to .pretrained_model; checkpoint that. With
    # LoRA the base is frozen, so enable_input_require_grads() is REQUIRED — else
    # the checkpointed segments have no grad-requiring input and the LoRA grad
    # never flows (silent no-learn). We set config.use_cache=False for the
    # training forward/backward (KV-cache is incompatible with checkpointing);
    # the rollout generate() below passes use_cache=True explicitly to override
    # this, so generation stays fast (it runs under no_grad — no activation cost).
    inner = getattr(policy, "pretrained_model", policy)
    if hasattr(inner, "gradient_checkpointing_enable"):
        inner.gradient_checkpointing_enable()
        if hasattr(inner, "enable_input_require_grads"):
            inner.enable_input_require_grads()
        if hasattr(inner, "config"):
            inner.config.use_cache = False
        logger.info("Gradient checkpointing enabled on policy (use_cache=False).")

    # KL reference = frozen snapshot of the SFT-initialised policy. We always
    # build an explicit reference (deepcopy, ~+1 model of VRAM) rather than
    # ref_model=None: adapter-disabling would anchor KL to the BARE BASE, pulling
    # the policy away from SFT. Anchoring to SFT is the standard PPO setup.
    ref_model = create_reference_model(policy)
    return policy, ref_model, tokenizer


def _step_logprobs_from_scores(
    response_ids: torch.Tensor,
    scores: Sequence[torch.Tensor],
    spans,
) -> List[Optional[List[float]]]:
    """Slice per-step token logprobs from generation ``scores`` by token span.

    ``scores`` is the tuple from ``generate(output_scores=True)``: one
    ``(1, vocab)`` logit tensor per *generated* token. We convert each to the
    logprob of the actually-sampled token, then bucket those into the step
    spans (P1-1 feeds these to the α-gate's entropy feature).
    """
    if not scores:
        return [None] * len(spans)
    # logprob of the sampled token at each generated position.
    tok_logprobs: List[float] = []
    n_gen = min(len(scores), response_ids.size(0))
    for t in range(n_gen):
        logits = scores[t][0]
        lp = torch.log_softmax(logits.float(), dim=-1)
        tok_id = int(response_ids[t].item())
        tok_logprobs.append(float(lp[tok_id].item()))
    out: List[Optional[List[float]]] = []
    for start, end in spans:
        s = max(0, start)
        e = min(end, len(tok_logprobs))
        out.append(tok_logprobs[s:e] if e > s else None)
    return out


def _prepare_prompts(reader: SilverDatasetReader, tokenizer, cfg: Phase3PPOConfig):
    rows = []
    skipped_no_gold = 0
    for traj in reader.accepted():
        # B3: cap passages (and triples) so the KG block survives prompt budgeting.
        msgs = build_rl_messages(
            question=traj.question,
            retrieved_passages=traj.retrieved_passages,
            kg_triples=traj.kg_subgraph,
            top_k=cfg.ppo_max_passages,
            max_kg_triples=cfg.ppo_max_kg_triples,
        )
        if hasattr(tokenizer, "apply_chat_template"):
            text = tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        else:
            text = "\n\n".join(m["content"] for m in msgs)
        # P0-3/A4: require a real dataset gold. The teacher answer is NOT a valid
        # EM target — rewarding it would teach PPO to match the teacher's
        # mistakes (reward hacking). Skip trajectories with no gold rather than
        # fall back to traj.answer.
        gold = str(traj.metadata.get("gold_answer") or "").strip()
        if not gold:
            skipped_no_gold += 1
            continue
        spec = RewardSpec(
            query=traj.question,
            gold_answer=gold,
            kg_subgraph=list(traj.kg_subgraph),
            retrieved_passages=list(traj.retrieved_passages),
            metadata={"qid": traj.qid, "dataset": traj.dataset},
        )
        rows.append({"prompt": text, "spec": spec})
    if skipped_no_gold:
        logger.warning(
            "Skipped %d accepted trajectories with no gold_answer (A4: no teacher fallback).",
            skipped_no_gold,
        )
    return rows


def _generate(policy, tokenizer, prompts: Sequence[str], cfg: Phase3PPOConfig, device: str):
    """Generate one response per prompt.

    SCALE: when ``use_real_logprobs`` is on we convert each prompt's generation
    ``scores`` to small per-step logprob lists *immediately* inside the loop and
    discard the raw logit tensors, so the whole batch's logits (≈GBs at
    batch_size=64) are never held in memory at once.
    """
    query_tensors, response_tensors, response_texts, logprobs_per_step_list = [], [], [], []
    # Read the device LIVE from the model: PPOTrainer/accelerate move the policy
    # to CUDA *after* run_phase3_ppo computed its `device` string, so the passed
    # `device` can be a stale "cpu". Trust where the params actually are now.
    try:
        device = next(p for p in policy.parameters()).device
    except StopIteration:
        pass
    for prompt in prompts:
        # B3: check length BEFORE truncation so a prompt that would lose its KG
        # block is a loud warning, not a silent grounding failure. With passages
        # capped in _prepare_prompts this should not trigger; if it does, lower
        # cfg.ppo_max_passages / ppo_max_kg_triples.
        full_len = len(tokenizer(prompt, truncation=False)["input_ids"])
        if full_len > cfg.max_input_length:
            logger.warning(
                "PPO prompt is %d tokens > max_input_length=%d; right-truncation will drop the "
                "trailing KG block. Lower ppo_max_passages (now %d) / ppo_max_kg_triples (now %d).",
                full_len, cfg.max_input_length, cfg.ppo_max_passages, cfg.ppo_max_kg_triples,
            )
        enc = tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=cfg.max_input_length,
        )
        query_ids = enc["input_ids"].to(device).squeeze(0)
        with torch.no_grad():
            out = policy.generate(
                input_ids=query_ids.unsqueeze(0),
                max_new_tokens=cfg.max_new_tokens,
                do_sample=True,
                temperature=cfg.temperature,
                top_p=cfg.top_p,
                # top_k=0 disables the default top-50 truncation: any truncation
                # (top_p<1 or top_k>0) makes the rollout distribution differ from
                # TRL's raw-logit logp recomputation and pushes KL negative.
                top_k=0,
                pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
                return_dict_in_generate=cfg.use_real_logprobs,
                output_scores=cfg.use_real_logprobs,
            )
        if cfg.use_real_logprobs:
            gen = out.sequences[0]
            response_ids = gen[query_ids.size(0):]
            # SCALE: collapse this prompt's raw scores into the small per-step
            # logprob lists RIGHT HERE, then drop the logits before the next
            # prompt — never accumulate raw scores across the batch.
            resp_text = tokenizer.decode(response_ids, skip_special_tokens=True)
            n_parsed = len(parse_steps(resp_text)[: cfg.max_steps])
            spans = step_spans_over_ids(response_ids, tokenizer, n_parsed)
            logprobs_per_step = _step_logprobs_from_scores(response_ids, out.scores, spans)
            del out
        else:
            gen = out[0]
            response_ids = gen[query_ids.size(0):]
            resp_text = tokenizer.decode(response_ids, skip_special_tokens=True)
            logprobs_per_step = None
        query_tensors.append(query_ids)
        response_tensors.append(response_ids)
        response_texts.append(resp_text)
        logprobs_per_step_list.append(logprobs_per_step)
    return query_tensors, response_tensors, response_texts, logprobs_per_step_list


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_phase3_ppo(cfg: Phase3PPOConfig) -> Dict[str, Any]:
    set_seed(cfg.seed)
    out_dir = Path(cfg.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    from trl import PPOConfig

    policy, ref_model, tokenizer = _build_models(cfg)
    # NOTE: at this point the policy still lives on CPU — PPOTrainer/accelerate
    # move it to CUDA later. So don't read the device off the (CPU) policy here;
    # pick the real training device directly. Reward components (text_reward etc.)
    # built below must land on the SAME device the policy ends up on.
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # ---- Build reward components ----------------------------------------
    alpha_gate = AlphaGate()
    if cfg.alpha_gate_path and Path(cfg.alpha_gate_path).exists():
        alpha_gate.load_state_dict(torch.load(cfg.alpha_gate_path, map_location="cpu"))
        logger.info("Loaded α-gate from %s", cfg.alpha_gate_path)
    alpha_gate.eval()

    # P0-2 / Finding 2: the (improved) PRMAnnotator with a LIVE entity cache so
    # link_confidence (the α-gate's middle feature) matches Phase 2 training. A
    # bare PRMAnnotator() builds an EntityLinker with an EMPTY cache →
    # link_confidence ≡ 0, which would make the gate's middle input dead at
    # inference and mismatch Phase 2.
    from kgproweight.retrieval.bootstrap import resolve_entity_cache_path
    from kgproweight.kg.entity_linker import EntityLinker

    _entity_linker = EntityLinker(cache_path=resolve_entity_cache_path())
    logger.info(
        "PPO link_confidence: EntityLinker cache=%s (%d entries)",
        resolve_entity_cache_path(), len(list(_entity_linker.cache.items())),
    )
    annotator = PRMAnnotator(entity_linker=_entity_linker, verbose=False)
    if cfg.pure_em_reward:
        # Pure EM ablation — ReaRAG-9B is never called.  Use a dummy to skip
        # the ~25 min model load and free ~18 GB of VRAM.
        from kgproweight.reward.text_reward_model import TextRewardModel, _DummyTextReward
        text_reward = TextRewardModel(_DummyTextReward(), name="dummy")
        logger.info("Pure EM mode: using DummyTextReward (ReaRAG-9B not loaded).")
    else:
        text_reward = build_text_reward_model(
            backend=cfg.text_reward_backend,
            fallback_head_path=cfg.text_reward_fallback_path,
            device=str(device),
            dtype=cfg.dtype,
        )
    reward_fn = KGProWeightRewardFunction(
        alpha_gate=alpha_gate,
        prm_annotator=annotator,
        text_reward_model=text_reward,
        tokenizer=tokenizer,
        outcome_weight=cfg.outcome_weight,
        discount=cfg.gamma,
        alpha_override=cfg.alpha_override,
        max_steps=cfg.max_steps,
        # R7: format-as-constraint (replaces step_format_bonus)
        min_valid_steps=getattr(cfg, "min_valid_steps", 3),
        pure_em=cfg.pure_em_reward,
        text_reward_scale=cfg.text_reward_scale,
    )

    # ---- Data ------------------------------------------------------------
    reader = SilverDatasetReader(cfg.silver_path)
    if cfg.binary_labels_only:
        for traj in reader.trajectories:
            for step in traj.steps:
                if step.label == 0:
                    step.label = -1  # collapse neutral into negative for this ablation

    samples = _prepare_prompts(reader, tokenizer, cfg)
    if not samples:
        raise ValueError(f"No PPO samples derived from {cfg.silver_path}")
    # SCALE: total_steps counts trajectories SEEN (n_seen += batch_size per
    # iteration), not epochs. For one full pass over the data it should be
    # >= ceil(len(samples)/batch_size) * batch_size. We do NOT change the
    # semantics here; just report so under-coverage is visible.
    full_coverage_steps = math.ceil(len(samples) / max(1, cfg.batch_size)) * cfg.batch_size
    logger.info(
        "Phase 3b PPO with %d prompts; batch_size=%d, total_steps=%d "
        "(>= %d needed for one full pass over the data).",
        len(samples), cfg.batch_size, cfg.total_steps, full_coverage_steps,
    )

    # ---- Trainer ---------------------------------------------------------
    ppo_cfg = PPOConfig(
        learning_rate=cfg.learning_rate,
        batch_size=cfg.batch_size,
        mini_batch_size=cfg.mini_batch_size,
        ppo_epochs=cfg.ppo_epochs,
        cliprange=cfg.cliprange,
        cliprange_value=cfg.cliprange_value,
        kl_penalty="kl",
        # KL control. init_kl_coef is the initial penalty coefficient for the
        # adaptive controller; cfg.target_kl is that controller's TARGET KL —
        # TRL's `target`, NOT TRL's `target_kl` (the latter is an early-stop
        # threshold that only fires when early_stopping=True). The previous code
        # wired cfg.target_kl into the early-stop knob (inert here) and left the
        # adaptive `target` at its default. Route it to the correct knob and make
        # adaptive control explicit.
        adap_kl_ctrl=True,
        init_kl_coef=cfg.kl_coef,
        target=cfg.target_kl,
        horizon=cfg.kl_horizon,
        gamma=cfg.gamma,
        lam=cfg.lam,
        max_grad_norm=cfg.max_grad_norm,
        vf_coef=cfg.vf_coef,
        early_stopping=cfg.early_stopping,
        # TRL's log_with is set to None — we handle WandB ourselves to
        # guarantee cloud sync even in the AutoDL offline environment.
        log_with=None,
        seed=cfg.seed,
    )
    # ---- WandB ----------------------------------------------------------
    # TRL 0.11.4's accelerator.init_trackers() is unreliable in the AutoDL
    # offline environment (R4 data never synced to cloud).  We bypass TRL
    # entirely: tell PPOConfig log_with=None, then init wandb ourselves
    # with explicit credentials and project settings from the config.
    _wandb_run = None
    try:
        import wandb as _wandb
        wandb_kwargs: Dict[str, Any] = dict(
            project="KG-ProWeight-PPO",
            name=f"R5_step{cfg.total_steps}_outcome{cfg.outcome_weight}_textscale{cfg.text_reward_scale}_kl{cfg.kl_coef}",
            config=asdict(cfg),
            tags=["R5", "mixed-data", f"steps{cfg.total_steps}"],
        )
        _wandb_run = _wandb.init(**wandb_kwargs)
        logger.info("WandB initialised: %s", _wandb_run.name if _wandb_run else "None")
    except Exception:
        logger.warning("WandB init failed — training will proceed without cloud logging.")

    # ---- Loop ------------------------------------------------------------
    rng = torch.Generator().manual_seed(cfg.seed)
    n_seen = 0
    history: List[Dict[str, float]] = []
    while n_seen < cfg.total_steps:
        batch_idx = torch.randint(0, len(samples), (cfg.batch_size,), generator=rng).tolist()
        batch_samples = [samples[i] for i in batch_idx]
        prompts = [s["prompt"] for s in batch_samples]
        specs: List[RewardSpec] = [s["spec"] for s in batch_samples]

        query_tensors, response_tensors, response_texts, logprobs_per_step_list = _generate(
            policy, tokenizer, prompts, cfg, device
        )

        token_reward_list: List[torch.Tensor] = []
        traj_rewards: List[float] = []
        for resp_text, response_ids, spec, logprobs_per_step in zip(
            response_texts, response_tensors, specs, logprobs_per_step_list
        ):
            # #6: compute step spans in response_ids coordinates ONCE; the reward
            # fn places per-step rewards on those same spans, so the placement
            # matches the trainer's scatter (no decode∘re-tokenise drift). The
            # entropy logprobs were already bucketed onto these spans in
            # _generate (SCALE: done per-prompt to avoid holding raw logits).
            n_parsed = len(parse_steps(resp_text)[: cfg.max_steps])
            aligned_spans = step_spans_over_ids(response_ids, tokenizer, n_parsed)
            info = reward_fn(
                prompt="",
                response=resp_text,
                spec=spec,
                logprobs_per_step=logprobs_per_step,
                response_ids=response_ids,
                step_spans=aligned_spans,
            )
            traj_rewards.append(info["trajectory_reward"])
            # token_rewards is already built in response_ids space (#6), so it
            # matches the response tensor length exactly — but stay defensive.
            tr = info["token_rewards"]
            n = response_ids.size(0)
            if tr.size(0) != n:
                tr = (torch.cat([tr, torch.zeros(n - tr.size(0), dtype=tr.dtype)])
                      if tr.size(0) < n else tr[:n])
            token_reward_list.append(tr)

        # P0-1 / #6: hand the per-token step rewards to the trainer so GAE runs
        # on them. The scalar `scores` arg is a placeholder (ignored by our
        # override when pending rewards are set) but must satisfy TRL's shape
        # checks: one scalar tensor per sample.
        placeholder_scores = [torch.zeros((), dtype=torch.float32) for _ in token_reward_list]
        trainer.set_pending_step_rewards(token_reward_list)
        stats = trainer.step(query_tensors, response_tensors, placeholder_scores)
        n_seen += cfg.batch_size
        # TRL exposes the (flattened) per-token advantages under "policy/advantages"
        # — there is NO "ppo/policy/advantages_var" key, so the old code logged a
        # constant 0.0. Compute the variance from the real array; a healthy PPO run
        # has var > 0 (zero variance ⇒ no learning signal).
        adv = stats.get("policy/advantages")
        try:
            import numpy as _np

            adv_var = float(_np.nanvar(_np.asarray(adv))) if adv is not None else 0.0
        except Exception:
            adv_var = 0.0

        def _stat(key):
            """Pull a TRL stat as a python float (handles numpy scalars/arrays)."""
            v = stats.get(key)
            if v is None:
                return None
            try:
                import numpy as _np
                return float(_np.asarray(v).mean())
            except Exception:
                return None

        history.append(
            {
                "step": n_seen,
                "mean_reward": float(sum(traj_rewards) / max(1, len(traj_rewards))),
                "ppo_mean_kl": float(stats.get("objective/kl", 0.0)),
                "advantage_var": adv_var,
                # PPO losses (so loss/clip curves are recoverable from history.jsonl).
                "loss_total": _stat("ppo/loss/total"),
                "loss_policy": _stat("ppo/loss/policy"),
                "loss_value": _stat("ppo/loss/value"),
                "policy_clipfrac": _stat("ppo/policy/clipfrac"),
                "policy_entropy": _stat("ppo/policy/entropy"),
                "policy_approxkl": _stat("ppo/policy/approxkl"),
            }
        )
        # WandB logging (independent of TRL's accelerator)
        if _wandb_run is not None:
            try:
                _wandb_run.log(
                    {
                        "custom/mean_reward": history[-1]["mean_reward"],
                        "custom/loss_total": history[-1].get("loss_total"),
                        "custom/loss_policy": history[-1].get("loss_policy"),
                        "custom/loss_value": history[-1].get("loss_value"),
                        "custom/advantage_var": history[-1].get("advantage_var"),
                        "custom/entropy": history[-1].get("policy_entropy"),
                        # Also mirror TRL's keys so they appear even if TRL fails
                        "objective/kl": history[-1].get("ppo_mean_kl"),
                        "ppo/policy/clipfrac": history[-1].get("policy_clipfrac"),
                    },
                    step=n_seen,
                )
            except Exception:
                pass

        if n_seen % (cfg.batch_size * 4) == 0:
            logger.info(
                "step=%d mean_reward=%.4f kl=%.4f loss=%.4f clipfrac=%.3f",
                n_seen,
                history[-1]["mean_reward"],
                history[-1]["ppo_mean_kl"],
                history[-1]["loss_total"] if history[-1]["loss_total"] is not None else float("nan"),
                history[-1]["policy_clipfrac"] if history[-1]["policy_clipfrac"] is not None else float("nan"),
            )

        # Intermediate checkpoint: save the (PEFT) adapter whenever n_seen crosses
        # a save_every_steps boundary, so a run that collapses can be rolled back
        # to the last healthy step. The crossing test (rather than `% == 0`) is
        # robust to a batch_size that does not divide save_every_steps. The final
        # save below writes a separate `final/` dir, so there is no double-save.
        if (
            cfg.save_every_steps > 0
            and n_seen < cfg.total_steps
            and (n_seen // cfg.save_every_steps) != ((n_seen - cfg.batch_size) // cfg.save_every_steps)
        ):
            ckpt_dir = out_dir / f"step_{n_seen}"
            trainer.save_pretrained(str(ckpt_dir))
            tokenizer.save_pretrained(ckpt_dir)
            # Persist history incrementally so a killed run keeps its curves and
            # the saved step's metrics are recoverable alongside the weights.
            with open(out_dir / "history.jsonl", "w", encoding="utf-8") as fh:
                for h in history:
                    fh.write(json.dumps(h) + "\n")
            logger.info("Saved intermediate PPO checkpoint at %s (step %d)", ckpt_dir, n_seen)

    final_dir = out_dir / "final"
    trainer.save_pretrained(str(final_dir))
    tokenizer.save_pretrained(final_dir)

    history_path = out_dir / "history.jsonl"
    with open(history_path, "w", encoding="utf-8") as fh:
        for h in history:
            fh.write(json.dumps(h) + "\n")

    dump_manifest(
        out_dir,
        extra={
            "phase": "phase3_ppo",
            "config": asdict(cfg),
            "history_tail": history[-5:],
        },
    )
    logger.info("Phase 3b PPO done. Final checkpoint at %s", final_dir)
    return {"output_dir": str(out_dir), "final_checkpoint": str(final_dir)}
