# R7 Rollback Script
# Run this to restore all files to pre-R7 state.
# Usage: powershell -File rollback.ps1

$backupDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Resolve-Path "$backupDir\..\.."

Write-Host "Rolling back R7 changes..."

Copy-Item "$backupDir\composite_reward.py.bak" "$projectRoot\kgproweight\reward\composite_reward.py" -Force
Copy-Item "$backupDir\reward_function.py.bak" "$projectRoot\kgproweight\training\reward_function.py" -Force
Copy-Item "$backupDir\phase3_ppo.py.bak" "$projectRoot\kgproweight\training\phase3_ppo.py" -Force
Copy-Item "$backupDir\phase3_ppo.yaml.bak" "$projectRoot\configs\training\phase3_ppo.yaml" -Force

Write-Host "Rollback complete. All files restored to pre-R7 state."
